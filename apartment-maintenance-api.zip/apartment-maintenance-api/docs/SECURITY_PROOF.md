# Security Proof

Three things need to be visible to the evaluator: a protected endpoint refusing
an anonymous call (**401**), the same endpoint accepting a valid JWT (**200**),
and a valid token being refused for the wrong role (**403**). Each step below
produces one screenshot.

Start the app first: `mvn spring-boot:run`.

---

## Proof 1 — 401 without a token

**Postman:** `GET http://localhost:8080/api/v1/requests`, no Authorization header.

**curl:**
```bash
curl -i http://localhost:8080/api/v1/requests
```

Expected:
```
HTTP/1.1 401
WWW-Authenticate: Bearer realm="apartment-maintenance-api"
Content-Type: application/json

{
  "timestamp": "2026-09-19T06:30:12Z",
  "status": 401,
  "code": "UNAUTHORIZED",
  "message": "Missing or invalid bearer token",
  "path": "/api/v1/requests"
}
```

Screenshot as `docs/screenshots/401-no-token.png` — make sure the red **401**
status and the empty Authorization tab are both visible.

---

## Proof 2 — 200 with a valid token

**Step A, get a token:**
```bash
curl -s -X POST http://localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@apt.com","password":"Admin@123"}'
```

**Step B, call the same endpoint:**
```bash
curl -i http://localhost:8080/api/v1/requests \
  -H "Authorization: Bearer <paste accessToken>"
```

Expected: `HTTP/1.1 200` and the paged JSON body.

In Postman use the **Authorization** tab, type *Bearer Token*. Screenshot as
`docs/screenshots/200-with-token.png` with the green **200** and the token field
visible (blur the middle of the token if you prefer).

---

## Proof 3 — 401 with a tampered token

```bash
curl -i http://localhost:8080/api/v1/requests \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.tampered.payload"
```

Expected `401`. This shows the signature is actually verified, not just the
presence of a header. Screenshot as `docs/screenshots/401-tampered-token.png`.

---

## Proof 4 — 403 for the wrong role

Log in as `resident@apt.com / Resident@123`, then:

```bash
curl -i -X POST http://localhost:8080/api/v1/flats \
  -H "Authorization: Bearer <resident token>" \
  -H 'Content-Type: application/json' \
  -d '{"flatNumber":"Z-999","block":"Z","floor":9,"ownerName":"Nobody","areaSqft":500,"occupied":false}'
```

Expected:
```
HTTP/1.1 403
{
  "timestamp": "...",
  "status": 403,
  "code": "FORBIDDEN",
  "message": "Your role is not allowed to perform this action",
  "path": "/api/v1/flats"
}
```

Screenshot as `docs/screenshots/403-wrong-role.png`.

---

## Proof 5 — the automated suite

```bash
mvn test
```

All the cases above are also asserted in `MaintenanceApiRestAssuredTest`:

| Test | Asserts |
|---|---|
| `protectedEndpointWithoutTokenReturns401` | 401 + `code = UNAUTHORIZED` |
| `tamperedTokenReturns401` | 401 on a forged signature |
| `wrongPasswordReturns401` | 401 + `code = BAD_CREDENTIALS` |
| `validTokenReturns200` | 200 + non-empty page |
| `residentCannotCreateFlat` | 403 + `code = FORBIDDEN` |
| `illegalTransitionReturns422` | 422 on a bad workflow jump |

Screenshot the green test summary as `docs/screenshots/mvn-test.png`, and the
Postman Collection Runner summary as `docs/screenshots/postman-runner.png`.

---

## What actually protects the API

| Measure | Where |
|---|---|
| BCrypt password hashing (strength 10) | `SecurityConfig.passwordEncoder()` |
| HS256-signed JWT, 1-hour expiry, issuer check | `JwtService` |
| Stateless sessions, no cookies | `SecurityConfig` (`SessionCreationPolicy.STATELESS`) |
| Deny-by-default (`anyRequest().authenticated()`) | `SecurityConfig` |
| Role rules at the method level | `@PreAuthorize` on controllers |
| Ownership rules (own flat / own assignment) | service layer, not the controller |
| Input validation on every payload | Jakarta Bean Validation on DTO records |
| SQL injection prevented | JPA/Criteria parameter binding only, no string SQL |
| No password or entity ever serialized | DTO records only |
| Uniform error body, no stack traces to clients | `GlobalExceptionHandler` |
| Secret read from an environment variable in production | `app.jwt.secret: ${APP_JWT_SECRET:...}` |
