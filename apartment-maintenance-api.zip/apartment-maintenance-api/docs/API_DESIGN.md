# API Design Document — Apartment Maintenance REST API v1

Base URL: `http://localhost:8080/api/v1`
Media type: `application/json` (UTF-8)
Auth: `Authorization: Bearer <JWT>` on everything except `/auth/**`

---

## 1. Resource model

| Resource | Collection URI | Description |
|---|---|---|
| User | `/users` | Residents, technicians, admins |
| Flat | `/flats` | Physical units in the society |
| MaintenanceRequest | `/requests` | A complaint raised against a flat |
| Comment | `/requests/{id}/comments` | Sub-resource: conversation on a complaint |
| Payment | `/payments` | Monthly maintenance bill for a flat |

Relationships: a `Flat` has many `User`s (residents); a `User` raises many
`MaintenanceRequest`s; a `MaintenanceRequest` belongs to one `Flat`, is raised by
one `User`, may be assigned to one technician, and has many `Comment`s; a `Flat`
has many `Payment`s (one per billing month, enforced as unique).

### Design rules applied

1. **Nouns, plural, lowercase** for collections — `/requests`, never `/getRequests`.
2. **HTTP verbs carry the intent** — `GET` read, `POST` create, `PUT` full
   replace, `PATCH` partial/workflow change, `DELETE` remove.
3. **Sub-resources for composition** — comments live under their parent request.
4. **`POST` returns 201 + `Location` header** pointing at the new resource.
5. **Entities are never exposed.** Every payload is a dedicated DTO record, so
   the password hash and lazy JPA proxies can never leak.
6. **One error shape everywhere** (`ApiError`), so clients write one handler.
7. **Collections are always paged** and returned inside the same envelope.

---

## 2. Status codes used

| Code | When |
|---|---|
| 200 OK | Successful `GET`, `PUT`, `PATCH` |
| 201 Created | Successful `POST` (with `Location`) |
| 204 No Content | Successful `DELETE` |
| 400 Bad Request | Bean-validation failure / bad query parameter type |
| 401 Unauthorized | Missing, malformed, tampered or expired JWT; bad credentials |
| 403 Forbidden | Valid token, but the role or ownership rule forbids the action |
| 404 Not Found | Unknown id |
| 409 Conflict | Duplicate email, flat number or bill for a month |
| 422 Unprocessable Entity | Business-rule violation (illegal workflow transition) |
| 500 Internal Server Error | Anything unexpected (still returns `ApiError`) |

---

## 3. Common envelopes

### Paged collection

```json
{
  "content": [ { "...": "resource objects" } ],
  "page": 0,
  "size": 10,
  "totalElements": 23,
  "totalPages": 3,
  "last": false
}
```

Query parameters supported on every collection: `page`, `size`,
`sort=<property>,<asc|desc>`.

### Error

```json
{
  "timestamp": "2026-09-19T06:36:20Z",
  "status": 400,
  "code": "VALIDATION_FAILED",
  "message": "Request validation failed",
  "path": "/api/v1/requests",
  "details": [
    { "field": "title", "issue": "must not be blank" },
    { "field": "priority", "issue": "must not be null" }
  ]
}
```

`details` is present only for validation errors.

---

## 4. Endpoint catalogue with samples

### 4.1 POST /api/v1/auth/register — public

Request
```json
{
  "email": "anita@apt.com",
  "password": "Anita@1234",
  "fullName": "Anita Desai",
  "phone": "9812345678",
  "flatId": 2
}
```

Response `201 Created`, `Location: /api/v1/users/5`
```json
{
  "id": 5,
  "email": "anita@apt.com",
  "fullName": "Anita Desai",
  "phone": "9812345678",
  "role": "RESIDENT",
  "flatId": 2,
  "flatNumber": "B-201"
}
```

Errors: `400` validation, `409` email already registered.

---

### 4.2 POST /api/v1/auth/login — public

Request
```json
{ "email": "admin@apt.com", "password": "Admin@123" }
```

Response `200 OK`
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhcGFydG1lbnQtbWFpbnRlbmFuY2UtYXBpIiwic3ViIjoiYWRtaW5AYXB0LmNvbSIsInJvbGUiOiJBRE1JTiIsInVpZCI6MSwiZXhwIjoxNzg5MTIzNDU2fQ.9tZ0k1nQbW4",
  "tokenType": "Bearer",
  "expiresInSeconds": 3600,
  "user": {
    "id": 1,
    "email": "admin@apt.com",
    "fullName": "Society Admin",
    "phone": "9000000001",
    "role": "ADMIN"
  }
}
```

Error `401`
```json
{
  "timestamp": "2026-09-19T06:30:12Z",
  "status": 401,
  "code": "BAD_CREDENTIALS",
  "message": "Email or password is incorrect",
  "path": "/api/v1/auth/login"
}
```

---

### 4.3 GET /api/v1/flats?page=0&size=2&sort=flatNumber,asc

Response `200 OK`
```json
{
  "content": [
    { "id": 1, "flatNumber": "A-402", "block": "A", "floor": 4, "ownerName": "Ravi Sharma", "areaSqft": 1150, "occupied": true },
    { "id": 2, "flatNumber": "B-201", "block": "B", "floor": 2, "ownerName": "Meera Iyer", "areaSqft": 980, "occupied": true }
  ],
  "page": 0,
  "size": 2,
  "totalElements": 3,
  "totalPages": 2,
  "last": false
}
```

### 4.4 POST /api/v1/flats — ADMIN only

Request
```json
{
  "flatNumber": "C-305",
  "block": "C",
  "floor": 3,
  "ownerName": "Kiran Rao",
  "areaSqft": 1020,
  "occupied": true
}
```
Response `201 Created` with the same object plus `"id": 4`.
A resident token on this call returns `403 FORBIDDEN`.

---

### 4.5 POST /api/v1/requests — RESIDENT or ADMIN

Request (resident; the flat is inferred from the token)
```json
{
  "title": "Kitchen tap leaking continuously",
  "description": "Water leaks from the base of the kitchen tap since yesterday evening.",
  "category": "PLUMBING",
  "priority": "HIGH"
}
```

Response `201 Created`, `Location: /api/v1/requests/3`
```json
{
  "id": 3,
  "title": "Kitchen tap leaking continuously",
  "description": "Water leaks from the base of the kitchen tap since yesterday evening.",
  "category": "PLUMBING",
  "priority": "HIGH",
  "status": "OPEN",
  "flatId": 1,
  "flatNumber": "A-402",
  "raisedById": 3,
  "raisedByName": "Ravi Sharma",
  "createdAt": "2026-09-19T06:12:44Z",
  "updatedAt": "2026-09-19T06:12:44Z"
}
```

`assignedToId`, `assignedToName`, `cost` and `resolvedAt` are omitted while null
(`spring.jackson.default-property-inclusion: non_null`).

---

### 4.6 GET /api/v1/requests?status=OPEN&priority=HIGH&page=0&size=5&sort=createdAt,desc

Scope rules applied server-side before the filter:

| Caller role | Rows returned |
|---|---|
| RESIDENT | only requests whose flat is the caller's flat |
| TECHNICIAN | only requests assigned to the caller |
| ADMIN | everything |

Response is the paged envelope from 3.1 with `MaintenanceRequestResponse` items.

---

### 4.7 PATCH /api/v1/requests/{id}/status

Request
```json
{
  "status": "ASSIGNED",
  "assignedToId": 2,
  "note": "Assigned to the in-house plumber."
}
```

Response `200 OK`
```json
{
  "id": 3,
  "title": "Kitchen tap leaking continuously",
  "category": "PLUMBING",
  "priority": "HIGH",
  "status": "ASSIGNED",
  "flatId": 1,
  "flatNumber": "A-402",
  "raisedById": 3,
  "raisedByName": "Ravi Sharma",
  "assignedToId": 2,
  "assignedToName": "Suresh Plumber",
  "createdAt": "2026-09-19T06:12:44Z",
  "updatedAt": "2026-09-19T06:20:03Z"
}
```

Illegal jump, e.g. `OPEN -> CLOSED`, response `422`
```json
{
  "timestamp": "2026-09-19T06:35:09Z",
  "status": 422,
  "code": "INVALID_STATE_TRANSITION",
  "message": "Cannot move a request from OPEN to CLOSED. Allowed: [ASSIGNED, REJECTED]",
  "path": "/api/v1/requests/3/status"
}
```

The optional `note` is stored as a `Comment`, so the workflow keeps an audit trail.

Later transitions: `{"status":"IN_PROGRESS"}`, then
`{"status":"RESOLVED","cost":750.00}` (sets `resolvedAt`), then
`{"status":"CLOSED"}` by the resident.

---

### 4.8 POST /api/v1/requests/{id}/comments

Request
```json
{ "message": "Plumber will visit tomorrow between 10-12." }
```

Response `201 Created`
```json
{
  "id": 7,
  "requestId": 3,
  "authorId": 1,
  "authorName": "Society Admin",
  "message": "Plumber will visit tomorrow between 10-12.",
  "createdAt": "2026-09-19T06:41:55Z"
}
```

---

### 4.9 POST /api/v1/payments — ADMIN only

Request
```json
{
  "flatId": 1,
  "billingMonth": "2026-10",
  "amount": 3500.00,
  "dueDate": "2026-10-10"
}
```

Response `201 Created`
```json
{
  "id": 3,
  "flatId": 1,
  "flatNumber": "A-402",
  "billingMonth": "2026-10",
  "amount": 3500.00,
  "status": "PENDING",
  "dueDate": "2026-10-10"
}
```

Second attempt for the same flat and month returns `409 DUPLICATE_RESOURCE`.

### 4.10 PATCH /api/v1/payments/{id}/settle

Request
```json
{ "referenceNo": "UPI-8827361" }
```

Response `200 OK`
```json
{
  "id": 1,
  "flatId": 1,
  "flatNumber": "A-402",
  "billingMonth": "2026-09",
  "amount": 3500.00,
  "status": "PAID",
  "dueDate": "2026-09-10",
  "paidAt": "2026-09-19T07:02:11Z",
  "referenceNo": "UPI-8827361"
}
```

---

### 4.11 GET /api/v1/requests/summary — ADMIN only

```json
{ "OPEN": 4, "ASSIGNED": 2, "IN_PROGRESS": 1, "RESOLVED": 3, "CLOSED": 9, "REJECTED": 1, "TOTAL": 20 }
```

---

## 5. Authorization matrix

| Endpoint | RESIDENT | TECHNICIAN | ADMIN |
|---|---|---|---|
| `POST /auth/**` | public | public | public |
| `GET /users/me` | yes | yes | yes |
| `GET/POST/DELETE /users` | no (403) | no (403) | yes |
| `GET /flats`, `GET /flats/{id}` | yes | yes | yes |
| `POST/PUT/DELETE /flats` | no (403) | no (403) | yes |
| `GET /requests` | own flat only | assigned only | all |
| `POST /requests` | yes | no (403) | yes |
| `PUT /requests/{id}` | own, while OPEN | no | yes |
| `PATCH /requests/{id}/status` | CLOSED only | assigned only | yes |
| `DELETE /requests/{id}` | no | no | yes |
| `GET /requests/summary` | no | no | yes |
| `GET /payments` | own flat only | all | all |
| `POST /payments` | no | no | yes |
| `PATCH /payments/{id}/settle` | own flat only | — | yes |

---

## 6. Versioning

The major version is the first path segment: `/api/v1/...`. See the report for
the rationale and the deprecation policy.
