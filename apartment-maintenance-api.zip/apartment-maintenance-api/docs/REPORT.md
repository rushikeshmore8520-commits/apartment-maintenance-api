# Apartment Maintenance REST API — Project Report

**Course project (15 marks) · Version 1.0.0 · September 2026**

---

## 1. Problem statement

A residential society of a few hundred flats runs its maintenance on WhatsApp
groups, a paper register at the security desk, and the secretary's memory. Three
problems follow from that:

1. **Nothing is traceable.** A complaint raised in a group chat scrolls away.
   Nobody can say when it was raised, who picked it up, or whether it was ever
   fixed.
2. **No accountability.** Because there is no state attached to a complaint,
   "it is being looked at" can mean anything for weeks. Repeat complaints about
   the same lift or the same pump are invisible.
3. **Billing is disconnected.** Monthly maintenance dues are tracked in a
   spreadsheet that only the treasurer has, so residents cannot check their own
   dues without asking.

The project builds a REST API that becomes the single source of truth for this
data and can be consumed by any front end — a resident mobile app, an admin web
dashboard, or the security desk tablet.

**Scope of v1:**

- Accounts with three roles: `RESIDENT`, `TECHNICIAN`, `ADMIN`.
- Flat master data.
- Maintenance complaints with category, priority and an enforced workflow
  (`OPEN → ASSIGNED → IN_PROGRESS → RESOLVED → CLOSED`, with `REJECTED` as an
  exit from the early states).
- A comment thread on each complaint, so the history of a job stays with the job.
- Monthly maintenance bills per flat, with settlement.
- Reporting: counts per status for the admin.

**Out of scope for v1:** payment-gateway integration, push notifications,
file/photo attachments, visitor management. These are noted in section 7.

---

## 2. Design decisions

### 2.1 Why Spring Boot (Option B)

Option A (JAX-RS/Jersey) and Option B were both acceptable. Spring Boot was
chosen because the three cross-cutting concerns in this project — security,
persistence and documentation — each have a first-party integration
(Spring Security, Spring Data JPA, springdoc-openapi) that plugs into the same
auto-configuration. With Jersey, the same result would have required manually
wiring a security filter, an EntityManager and Swagger Core. The saved effort
went into the domain rules instead.

### 2.2 Layering

```
Controller  →  Service  →  Repository  →  Database
   DTO in/out   business rules   Spring Data JPA      H2
```

Controllers are deliberately thin: they bind and validate the DTO, call one
service method and return. All decisions — who may see what, whether a status
change is legal, whether a bill already exists — live in the service layer. This
matters for testability and it means the rules cannot be bypassed by adding a
second controller later.

### 2.3 DTOs instead of entities

No JPA entity is ever serialized. Every request and response body is a Java
`record` in the `dto` package. Three concrete reasons:

- The `User` entity carries a BCrypt password hash. Returning the entity would
  leak it.
- Lazy Hibernate proxies serialize badly and can trigger extra queries or
  infinite recursion through bidirectional relationships.
- The wire format becomes free to evolve independently of the database schema,
  which is what makes versioning (section 3) practical at all.

Records were a good fit: immutable, concise, and Jackson handles them natively.

### 2.4 Resource modelling

URIs are plural nouns; HTTP verbs carry the intent. Comments are modelled as a
sub-resource (`/requests/{id}/comments`) because a comment has no meaning outside
its parent complaint.

The one interesting decision was the workflow. A tempting design is
`POST /requests/{id}/assign`, `POST /requests/{id}/resolve` and so on — but those
are verbs in URIs, and the set of them grows with every new state. Instead there
is a single `PATCH /requests/{id}/status` that takes the target state. The
service validates the transition against a state machine encoded in the
`RequestStatus` enum itself:

```java
case OPEN        -> EnumSet.of(ASSIGNED, REJECTED);
case ASSIGNED    -> EnumSet.of(IN_PROGRESS, REJECTED);
case IN_PROGRESS -> EnumSet.of(RESOLVED);
case RESOLVED    -> EnumSet.of(CLOSED, IN_PROGRESS);
case CLOSED, REJECTED -> EnumSet.noneOf(RequestStatus.class);
```

An illegal jump returns `422 Unprocessable Entity` — the request was
syntactically fine, so `400` would have been misleading.

### 2.5 PUT versus PATCH

`PUT /requests/{id}` replaces the editable descriptive fields and is idempotent.
`PATCH /requests/{id}/status` changes one aspect of the resource. Keeping them
apart means a resident correcting a typo can never accidentally alter the
workflow state.

### 2.6 Uniform errors

Every failure — validation, 401, 403, 404, 409, 422, 500 — returns the same
`ApiError` shape with a machine-readable `code`, a human `message`, the `path`
and a timestamp. A client writes one error handler instead of five. Spring's
default error body was deliberately replaced, including for the security
failures, which are produced by a custom `AuthenticationEntryPoint` and
`AccessDeniedHandler` so they match the rest.

### 2.7 Pagination as a default, not an option

Every collection endpoint is paged (`page`, `size`, `sort`) with a default size
of 10, wrapped in a `PageResponse` envelope. Spring's own `Page` serialization
was avoided because its JSON shape is verbose and has changed between Spring
versions — which would have been an accidental breaking change for clients.

### 2.8 Filtering with Criteria Specifications

The first implementation used a JPQL query with `(:status IS NULL OR r.status = :status)`
repeated per filter. It worked but it is fragile with typed enum parameters on
Hibernate 6 and it does not compose. It was replaced with JPA
`Specification`s, where each filter is a small function that returns
`cb.conjunction()` when its parameter is absent. Filters then combine with
`.and(...)`, and the role-scoping rule (a resident only ever sees their own flat)
is applied by appending one more specification server-side — it cannot be
overridden by a query parameter.

### 2.9 H2 in-memory

H2 keeps the project runnable with a single command and no database install,
which matters for evaluation. Because the code only uses JPA, switching to MySQL
is a three-line change in `application.yml`. A `DataSeeder` loads demo flats,
users, complaints and bills at startup so the API is demonstrable immediately.

---

## 3. Versioning strategy

**Chosen approach: URI path versioning.** Every endpoint lives under
`/api/v1/...`.

The alternatives were considered:

| Strategy | Example | Why not chosen |
|---|---|---|
| **URI path** | `/api/v1/requests` | **Chosen.** Obvious in logs, in Postman and in a browser; trivial to route; easy to run two versions side by side |
| Query parameter | `/api/requests?version=1` | Easy to forget; pollutes the filter parameters; caches treat it inconsistently |
| Custom header | `X-API-Version: 1` | Invisible in a browser; harder to demo and debug; every client must be configured |
| Content negotiation | `Accept: application/vnd.apt.v1+json` | The most "correct" REST answer, but high ceremony for a society app and awkward in Postman |

URI versioning trades a little purity (the version arguably belongs in the
representation, not the identifier) for a large amount of practical clarity. For
a project whose clients will be a mobile app and a dashboard maintained by the
same team, that is the right trade.

**Policy for changes:**

- *Additive changes stay in v1.* A new optional field in a response, a new
  optional query parameter, a new endpoint, a new enum value in a request — none
  of these break an existing client, so they ship without a version bump.
  Clients are expected to ignore unknown fields.
- *Breaking changes create v2.* Removing or renaming a field, changing a type,
  making an optional field required, changing a status code, or altering the
  state machine's meaning.
- *Both versions run together.* `v2` controllers sit in a parallel package; the
  service layer is shared where the behaviour is unchanged. `v1` is marked
  deprecated in the OpenAPI document, returns a `Deprecation` header, and is
  supported for a published window (six months) before removal.
- The version number in `pom.xml` follows semantic versioning; only the major
  component appears in the URI, so `1.4.2` and `1.0.0` both serve `/api/v1`.

---

## 4. Security measures

Security is the part of the project with the most deliberate decisions, so they
are listed with the reasoning rather than as a checklist.

**Stateless JWT rather than server sessions.** The API is consumed by a mobile
app and a dashboard, possibly on different origins. Sessions would need sticky
routing or a shared session store, and CSRF protection for cookies. A signed
bearer token needs neither. `SessionCreationPolicy.STATELESS` ensures Spring
never creates an `HttpSession`, and CSRF protection is disabled *because* there
are no cookies to forge — disabling it on a cookie-authenticated API would be a
serious mistake, so this decision is deliberate and narrow.

**Token contents and signing.** Tokens are HS256-signed with a 256-bit secret,
carry `sub` (email), `uid`, `role`, `name`, `iss`, `iat` and `exp`, and expire
after one hour. The issuer is verified on every parse, so a token minted by some
other service with the same key would still be rejected. The secret is read from
`APP_JWT_SECRET` with a development fallback — in a real deployment the fallback
is removed and the variable is mandatory.

**Passwords.** BCrypt with the default strength of 10. BCrypt salts each hash
automatically and is deliberately slow, which is what makes offline brute force
expensive. Passwords are never logged and never returned in any response.

**Two layers of authorization.** Role checks are declarative, using
`@PreAuthorize("hasRole('ADMIN')")` on the controller methods, which keeps the
role rule visible right next to the endpoint. But role alone is not enough:
"a resident may read complaints" must mean "*their own* complaints". That
ownership check needs the data, so it lives in the service layer
(`assertCanView`, and the scoping specification on list endpoints). The
separation is intentional — coarse role rules at the edge, fine-grained
ownership rules where the data is.

**Deny by default.** The filter chain ends with `anyRequest().authenticated()`,
and only an explicit list of paths (`/api/v1/auth/login`, `/api/v1/auth/register`,
the OpenAPI endpoints, the H2 console, the health check) is public. A new
controller added tomorrow is protected automatically — the failure mode is a
locked door, not an open one.

**Privilege escalation blocked at registration.** `POST /api/v1/auth/register`
accepts a `role` field, but `AuthService` rejects anything other than `RESIDENT`.
Without that check, anyone could self-register as an `ADMIN`. Staff accounts are
created only through `POST /api/v1/users`, which is admin-only.

**Input validation.** Every DTO carries Jakarta Bean Validation constraints
(`@NotBlank`, `@Email`, `@Size`, `@Pattern` for phone numbers and the `YYYY-MM`
billing month, `@DecimalMin` for amounts). Invalid input is rejected with a `400`
listing the offending fields, before it reaches any business logic.

**Injection.** All data access goes through Spring Data repositories and the
Criteria API, so values are bound as parameters. There is no string-concatenated
SQL or JPQL anywhere in the codebase.

**Information disclosure.** The `GlobalExceptionHandler` catches everything,
including unexpected exceptions, and returns only an error code and a short
message. Stack traces and class names of internal failures never reach the
client. A login failure returns one generic message for both "no such user" and
"wrong password", so the endpoint cannot be used to enumerate registered emails.

**Known gaps, honestly stated.** v1 has no refresh tokens (a user re-authenticates
after an hour), no token revocation list (a stolen token is valid until it
expires — mitigated by the short lifetime), no rate limiting on the login
endpoint, and permissive CORS suitable for development only. Section 7 lists the
fixes.

---

## 5. Testing

Two independent suites, because the deliverables allow either and each catches
different things.

**REST Assured + JUnit 5** (`MaintenanceApiRestAssuredTest`) boots the real
application on a random port and exercises it over HTTP, so the filter chain,
serialization and validation are all live. Twelve tests cover the security proofs
(401 without a token, 401 on a tampered token, 401 on a wrong password, 403 for
the wrong role, 200 with a valid token), the happy path (register → login →
raise → assign), and the error paths (400, 404, 409, 422). Tests are ordered
because the later ones consume the id created by the earlier ones.

**Postman collection** (`postman/Apartment-Maintenance-API.postman_collection.json`)
mirrors the same scenarios for manual demonstration. The login requests capture
the returned token into collection variables with a test script, so the whole
collection runs top to bottom in the Collection Runner without any copy-paste.
Assertions are written with `pm.test`, so the Runner produces a pass/fail summary
suitable for a screenshot.

**Documentation as a test.** One REST Assured test fetches `/v3/api-docs` and
asserts that the document is valid OpenAPI 3 with the right title. If an
annotation breaks the generated spec, the build fails rather than the evaluator
discovering it.

---

## 6. Challenges faced

**Null-safe filtering.** The obvious JPQL approach —
`(:status IS NULL OR r.status = :status)` — is brittle with typed enum parameters
on Hibernate 6, which cannot always infer the parameter type when it appears only
in an `IS NULL` test. Rather than scatter casts through the query, the filters
were rewritten as Criteria `Specification`s. This turned out better than the
original: filters now compose, and the role-scoping rule is just one more
specification appended server-side.

**Making 401 and 403 look like every other error.** Spring Security's
authentication failures happen inside the filter chain, *before* any
`@RestControllerAdvice` runs, so `GlobalExceptionHandler` never sees them. The
default output is an empty body or Spring's generic error page — inconsistent
with every other error the API returns. The fix was a custom
`AuthenticationEntryPoint` and `AccessDeniedHandler` in `SecurityConfig` that
serialize the same `ApiError` shape directly to the response, plus a proper
`WWW-Authenticate` header on the 401.

**Distinguishing 401 from 403.** Early on, a resident calling an admin endpoint
received a 401. The cause was that `AccessDeniedException` from `@PreAuthorize`
was being handled by the entry point rather than the access-denied handler.
Getting this right matters: 401 means "I do not know who you are", 403 means "I
know exactly who you are and you still may not do this", and a client that
retries a login on a 403 will loop forever.

**Choosing the right code for a bad workflow transition.** `OPEN → CLOSED` is
well-formed JSON with a valid enum value, so `400` would be wrong. `409` implies
a conflict with the current state of a resource, which is close but usually means
a duplicate. `422 Unprocessable Entity` — syntactically correct but semantically
rejected — is the accurate answer, and the response message lists the transitions
that *are* allowed so the client can recover.

**Lazy loading and JSON.** An early version returned entities directly and threw
`LazyInitializationException` once `open-in-view` was disabled. Keeping
`open-in-view: false` (it hides N+1 queries behind the view layer) and mapping to
DTOs inside the transactional service method solved the symptom and the cause at
once.

**JJWT 0.12 API change.** Most tutorials online use the pre-0.12 builder
(`setSubject`, `signWith(key, algorithm)`, `parserBuilder()`), which no longer
compiles. Version 0.12 moved to `subject()`, `signWith(key)` and
`Jwts.parser().verifyWith(key)`. The fix was to read the library's own migration
notes rather than trusting the first search result.

---

## 7. Future work

| Area | Planned change |
|---|---|
| Auth | Short-lived access token + rotating refresh token; a revocation list for logout |
| Hardening | Rate limiting and lockout on `/auth/login`; a restrictive CORS allow-list per environment |
| Features | Photo attachments on complaints; email/push notification on status change; SLA timers per priority |
| Payments | Integration with a UPI/payment gateway and automatic `OVERDUE` marking by a scheduled job |
| Operations | Flyway migrations instead of `ddl-auto`; MySQL in production; structured JSON logging with a correlation id |
| API | A `v2` with cursor-based pagination for large complaint histories |

---

## 8. Conclusion

The project delivers a working, documented and secured REST API covering the full
maintenance lifecycle of an apartment society. The parts worth pointing at are
not the CRUD endpoints but the decisions around them: a workflow encoded as a
state machine and enforced server-side, authorization split between declarative
role rules and data-dependent ownership rules, one error contract for every
failure mode, and a versioning policy written down before it was needed rather
than after the first breaking change.

---

### Appendix — how to run

```bash
mvn clean spring-boot:run          # starts on :8080 with seeded demo data
mvn test                           # runs the REST Assured suite
```

Swagger UI: `http://localhost:8080/swagger-ui.html`
Demo admin: `admin@apt.com / Admin@123`
