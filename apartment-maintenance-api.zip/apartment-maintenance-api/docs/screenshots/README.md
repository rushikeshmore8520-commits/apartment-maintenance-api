# Screenshots

Capture these before submitting (see ../SECURITY_PROOF.md for the exact steps):

| File | What it must show |
|---|---|
| `swagger-ui.png` | http://localhost:8080/swagger-ui.html with all five tags expanded and the green Authorize button |
| `swagger-authorize.png` | The Authorize dialog with the bearer token pasted in |
| `401-no-token.png` | Postman GET /api/v1/requests, no Authorization header, status **401** |
| `401-tampered-token.png` | Same call with a forged token, status **401** |
| `200-with-token.png` | Same call with a valid Bearer token, status **200** and the JSON page body |
| `403-wrong-role.png` | Resident token on POST /api/v1/flats, status **403** |
| `postman-runner.png` | Collection Runner summary, all assertions passing |
| `mvn-test.png` | Terminal showing the REST Assured suite green |
| `h2-console.png` | Optional: the seeded tables in the H2 console |
