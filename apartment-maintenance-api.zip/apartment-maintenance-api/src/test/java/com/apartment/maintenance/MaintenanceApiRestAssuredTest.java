package com.apartment.maintenance;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;

import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

/**
 * End-to-end REST Assured tests. They start the real application on a random
 * port, so the JWT filter, validation and the role rules are all exercised.
 *
 * Run with:  mvn test
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class MaintenanceApiRestAssuredTest {

    @LocalServerPort
    int port;

    static String adminToken;
    static String residentToken;
    static Integer createdRequestId;

    @BeforeEach
    void setUp() {
        RestAssured.port = port;
        RestAssured.basePath = "";
    }

    private String login(String email, String password) {
        return given()
                .contentType(ContentType.JSON)
                .body(Map.of("email", email, "password", password))
        .when()
                .post("/api/v1/auth/login")
        .then()
                .statusCode(200)
                .body("tokenType", equalTo("Bearer"))
                .extract().path("accessToken");
    }

    // ---------------- security proof ----------------

    @Test @Order(1)
    @DisplayName("401 - protected endpoint without a token")
    void protectedEndpointWithoutTokenReturns401() {
        given()
        .when()
                .get("/api/v1/requests")
        .then()
                .statusCode(401)
                .body("code", equalTo("UNAUTHORIZED"));
    }

    @Test @Order(2)
    @DisplayName("401 - protected endpoint with a tampered token")
    void tamperedTokenReturns401() {
        given()
                .header("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.garbage.signature")
        .when()
                .get("/api/v1/requests")
        .then()
                .statusCode(401);
    }

    @Test @Order(3)
    @DisplayName("401 - login with wrong password")
    void wrongPasswordReturns401() {
        given()
                .contentType(ContentType.JSON)
                .body(Map.of("email", "admin@apt.com", "password", "WrongPass1"))
        .when()
                .post("/api/v1/auth/login")
        .then()
                .statusCode(401)
                .body("code", equalTo("BAD_CREDENTIALS"));
    }

    @Test @Order(4)
    @DisplayName("200 - protected endpoint with a valid token")
    void validTokenReturns200() {
        adminToken = login("admin@apt.com", "Admin@123");
        residentToken = login("resident@apt.com", "Resident@123");

        given()
                .header("Authorization", "Bearer " + adminToken)
        .when()
                .get("/api/v1/requests")
        .then()
                .statusCode(200)
                .body("content.size()", greaterThan(0))
                .body("totalElements", greaterThan(0));
    }

    @Test @Order(5)
    @DisplayName("403 - resident cannot create a flat")
    void residentCannotCreateFlat() {
        given()
                .header("Authorization", "Bearer " + residentToken)
                .contentType(ContentType.JSON)
                .body(Map.of("flatNumber", "Z-999", "block", "Z", "floor", 9,
                        "ownerName", "Nobody", "areaSqft", 500, "occupied", false))
        .when()
                .post("/api/v1/flats")
        .then()
                .statusCode(403)
                .body("code", equalTo("FORBIDDEN"));
    }

    // ---------------- happy path ----------------

    @Test @Order(6)
    @DisplayName("201 - resident raises a maintenance request")
    void residentCanRaiseRequest() {
        createdRequestId = given()
                .header("Authorization", "Bearer " + residentToken)
                .contentType(ContentType.JSON)
                .body(Map.of("title", "Bathroom light not working",
                        "description", "The tube light in the guest bathroom stopped working.",
                        "category", "ELECTRICAL",
                        "priority", "MEDIUM"))
        .when()
                .post("/api/v1/requests")
        .then()
                .statusCode(201)
                .header("Location", containsString("/api/v1/requests/"))
                .body("status", equalTo("OPEN"))
                .body("flatNumber", equalTo("A-402"))
                .extract().path("id");
    }

    @Test @Order(7)
    @DisplayName("400 - validation failure on an empty title")
    void validationFailureReturns400() {
        given()
                .header("Authorization", "Bearer " + residentToken)
                .contentType(ContentType.JSON)
                .body(Map.of("title", "", "description", "x",
                        "category", "ELECTRICAL", "priority", "MEDIUM"))
        .when()
                .post("/api/v1/requests")
        .then()
                .statusCode(400)
                .body("code", equalTo("VALIDATION_FAILED"))
                .body("details.size()", greaterThan(0));
    }

    @Test @Order(8)
    @DisplayName("200 - admin assigns the request to a technician")
    void adminCanAssignRequest() {
        Integer techId = given()
                .header("Authorization", "Bearer " + adminToken)
        .when()
                .get("/api/v1/users?role=TECHNICIAN")
        .then()
                .statusCode(200)
                .extract().path("content[0].id");

        given()
                .header("Authorization", "Bearer " + adminToken)
                .contentType(ContentType.JSON)
                .body(Map.of("status", "ASSIGNED", "assignedToId", techId,
                        "note", "Assigned to the in-house electrician."))
        .when()
                .patch("/api/v1/requests/" + createdRequestId + "/status")
        .then()
                .statusCode(200)
                .body("status", equalTo("ASSIGNED"))
                .body("assignedToId", equalTo(techId));
    }

    @Test @Order(9)
    @DisplayName("422 - illegal workflow jump is rejected")
    void illegalTransitionReturns422() {
        given()
                .header("Authorization", "Bearer " + adminToken)
                .contentType(ContentType.JSON)
                .body(Map.of("status", "CLOSED"))
        .when()
                .patch("/api/v1/requests/" + createdRequestId + "/status")
        .then()
                .statusCode(422)
                .body("code", equalTo("INVALID_STATE_TRANSITION"));
    }

    @Test @Order(10)
    @DisplayName("404 - unknown request id")
    void unknownIdReturns404() {
        given()
                .header("Authorization", "Bearer " + adminToken)
        .when()
                .get("/api/v1/requests/999999")
        .then()
                .statusCode(404)
                .body("code", equalTo("RESOURCE_NOT_FOUND"));
    }

    @Test @Order(11)
    @DisplayName("409 - duplicate registration email")
    void duplicateEmailReturns409() {
        given()
                .contentType(ContentType.JSON)
                .body(Map.of("email", "resident@apt.com", "password", "Another@123",
                        "fullName", "Copy Cat", "phone", "9999999999"))
        .when()
                .post("/api/v1/auth/register")
        .then()
                .statusCode(409)
                .body("code", equalTo("DUPLICATE_RESOURCE"));
    }

    @Test @Order(12)
    @DisplayName("200 - OpenAPI document is published")
    void openApiDocIsAvailable() {
        given()
        .when()
                .get("/v3/api-docs")
        .then()
                .statusCode(200)
                .body("openapi", startsWith("3."))
                .body("info.title", equalTo("Apartment Maintenance REST API"));
    }
}
