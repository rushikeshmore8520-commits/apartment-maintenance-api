package com.apartment.maintenance.service;

import com.apartment.maintenance.dto.PageResponse;
import com.apartment.maintenance.dto.RequestDtos.*;
import com.apartment.maintenance.entity.*;
import com.apartment.maintenance.exception.*;
import com.apartment.maintenance.repository.*;
import com.apartment.maintenance.security.CurrentUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MaintenanceRequestService {

    private final MaintenanceRequestRepository requestRepository;
    private final CommentRepository commentRepository;
    private final FlatRepository flatRepository;
    private final UserRepository userRepository;
    private final CurrentUser currentUser;

    public PageResponse<RequestResponse> list(RequestStatus status, Category category,
                                              Priority priority, Long flatId, Pageable pageable) {
        User me = currentUser.get();

        // A resident may only ever see complaints belonging to their own flat.
        Long effectiveFlatId = flatId;
        if (me.getRole() == Role.RESIDENT) {
            if (me.getFlat() == null) {
                throw new AccessDeniedException("Your account is not linked to a flat");
            }
            effectiveFlatId = me.getFlat().getId();
        }

        Specification<MaintenanceRequest> spec = Specification
                .where(RequestSpecifications.hasStatus(status))
                .and(RequestSpecifications.hasCategory(category))
                .and(RequestSpecifications.hasPriority(priority))
                .and(RequestSpecifications.hasFlat(effectiveFlatId));

        if (me.getRole() == Role.TECHNICIAN) {
            spec = spec.and(RequestSpecifications.assignedTo(me.getId()));
        }

        return PageResponse.of(requestRepository.findAll(spec, pageable), RequestResponse::from);
    }

    public RequestResponse get(Long id) {
        MaintenanceRequest r = find(id);
        assertCanView(r);
        return RequestResponse.from(r);
    }

    @Transactional
    public RequestResponse create(CreateRequest req) {
        User me = currentUser.get();

        Flat flat;
        if (me.getRole() == Role.RESIDENT) {
            flat = me.getFlat();
            if (flat == null) throw new AccessDeniedException("Your account is not linked to a flat");
        } else {
            if (req.flatId() == null) {
                throw new InvalidStateTransitionException("flatId is required when an admin raises a request");
            }
            flat = flatRepository.findById(req.flatId())
                    .orElseThrow(() -> new ResourceNotFoundException("Flat", req.flatId()));
        }

        MaintenanceRequest r = MaintenanceRequest.builder()
                .title(req.title()).description(req.description())
                .category(req.category()).priority(req.priority())
                .status(RequestStatus.OPEN)
                .flat(flat).raisedBy(me)
                .build();

        return RequestResponse.from(requestRepository.save(r));
    }

    @Transactional
    public RequestResponse update(Long id, UpdateRequest req) {
        MaintenanceRequest r = find(id);
        User me = currentUser.get();

        boolean owner = r.getRaisedBy().getId().equals(me.getId());
        if (!owner && me.getRole() != Role.ADMIN) {
            throw new AccessDeniedException("Only the author or an admin can edit this request");
        }
        if (r.getStatus() != RequestStatus.OPEN && me.getRole() != Role.ADMIN) {
            throw new InvalidStateTransitionException("A request can only be edited while it is OPEN");
        }

        r.setTitle(req.title());
        r.setDescription(req.description());
        r.setCategory(req.category());
        r.setPriority(req.priority());
        return RequestResponse.from(requestRepository.save(r));
    }

    /** PATCH - drives the workflow and validates the state machine. */
    @Transactional
    public RequestResponse changeStatus(Long id, StatusUpdate req) {
        MaintenanceRequest r = find(id);
        User me = currentUser.get();

        if (me.getRole() == Role.RESIDENT && req.status() != RequestStatus.CLOSED) {
            throw new AccessDeniedException("A resident may only close a resolved request");
        }

        if (!r.getStatus().allowedNext().contains(req.status())) {
            throw new InvalidStateTransitionException(
                    "Cannot move a request from " + r.getStatus() + " to " + req.status()
                            + ". Allowed: " + r.getStatus().allowedNext());
        }

        if (req.status() == RequestStatus.ASSIGNED) {
            if (req.assignedToId() == null) {
                throw new InvalidStateTransitionException("assignedToId is required when assigning a request");
            }
            User tech = userRepository.findById(req.assignedToId())
                    .orElseThrow(() -> new ResourceNotFoundException("User", req.assignedToId()));
            if (tech.getRole() != Role.TECHNICIAN) {
                throw new InvalidStateTransitionException("User " + tech.getId() + " is not a TECHNICIAN");
            }
            r.setAssignedTo(tech);
        }

        if (req.status() == RequestStatus.RESOLVED) {
            r.setResolvedAt(Instant.now());
            if (req.cost() != null) r.setCost(req.cost());
        }

        r.setStatus(req.status());
        MaintenanceRequest saved = requestRepository.save(r);

        if (req.note() != null && !req.note().isBlank()) {
            commentRepository.save(Comment.builder().request(saved).author(me).message(req.note()).build());
        }
        return RequestResponse.from(saved);
    }

    @Transactional
    public void delete(Long id) {
        requestRepository.delete(find(id));
    }

    public List<CommentResponse> comments(Long requestId) {
        MaintenanceRequest r = find(requestId);
        assertCanView(r);
        return commentRepository.findByRequestIdOrderByCreatedAtAsc(r.getId())
                .stream().map(CommentResponse::from).toList();
    }

    @Transactional
    public CommentResponse addComment(Long requestId, CommentRequest req) {
        MaintenanceRequest r = find(requestId);
        assertCanView(r);
        Comment c = Comment.builder().request(r).author(currentUser.get()).message(req.message()).build();
        return CommentResponse.from(commentRepository.save(c));
    }

    public java.util.Map<String, Long> summary() {
        java.util.Map<String, Long> out = new java.util.LinkedHashMap<>();
        for (RequestStatus s : RequestStatus.values()) {
            out.put(s.name(), requestRepository.countByStatus(s));
        }
        out.put("TOTAL", requestRepository.count());
        return out;
    }

    private MaintenanceRequest find(Long id) {
        return requestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceRequest", id));
    }

    private void assertCanView(MaintenanceRequest r) {
        User me = currentUser.get();
        if (me.getRole() == Role.ADMIN) return;
        if (me.getRole() == Role.TECHNICIAN) {
            if (r.getAssignedTo() != null && r.getAssignedTo().getId().equals(me.getId())) return;
            throw new AccessDeniedException("This request is not assigned to you");
        }
        if (me.getFlat() != null && me.getFlat().getId().equals(r.getFlat().getId())) return;
        throw new AccessDeniedException("This request does not belong to your flat");
    }
}
