package com.apartment.maintenance.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "flats")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Flat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 20)
    private String flatNumber;

    @Column(nullable = false, length = 10)
    private String block;

    @Column(nullable = false)
    private Integer floor;

    @Column(nullable = false, length = 120)
    private String ownerName;

    @Column(nullable = false)
    private Integer areaSqft;

    @Column(nullable = false)
    private Boolean occupied;
}
