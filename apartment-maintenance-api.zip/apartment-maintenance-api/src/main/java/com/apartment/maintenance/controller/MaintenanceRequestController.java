package com.apartment.maintenance.controller;

import com.apartment.maintenance.dto.PageResponse;
import com.apartment.maintenance.dto.RequestDtos.*;
import com.apartment.maintenance.entity.*;
import com.apartment.maintenance.exception.ApiError;
import com.apartment.maintenance.service.MaintenanceRequestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/requests")
@RequiredArgsConstructor
@Tag(name = "Maintenance Requests", description = "Raise, track and resolve maintenance complaints")
@SecurityRequirement(name = "bearerAuth")
public class MaintenanceRequestController {

    private final MaintenanceRequestService service;

    @GetMapping
    @Operation(summary = "List requests with filtering, sorting and pagination",
            description = """
                    Residents see only their own flat's requests, technicians see only requests
                    assigned to them, admins see everything.
                    Example: `/api/v1/requests?status=OPEN&priority=HIGH&page=0&size=5&sort=createdAt,desc`
                    """)
    public PageResponse<RequestResponse> list(
            @Parameter(description = "Filter by workflow status") @RequestParam(required = false) RequestStatus status,
            @Parameter(description = "Filter by category") @RequestParam(required = false) Category category,
            @Parameter(description = "Filter by priority") @RequestParam(required = false) Priority priority,
            @Parameter(description = "Filter by flat (ignored for residents)") @RequestParam(required = false) Long flatId,
            @PageableDefault(size = 10, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        return service.list(status, category, priority, flatId, pageable);
    }

    @GetMapping("/summary")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Count of requests per status (ADMIN only)")
    public Map<String, Long> summary() {
        return service.summary();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get one request")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Found"),
            @ApiResponse(responseCode = "401", description = "No/invalid token",
                    content = @Content(schema = @Schema(implementation = ApiError.class))),
            @ApiResponse(responseCode = "403", description = "Not your flat / not assigned to you",
                    content = @Content(schema = @Schema(implementation = ApiError.class))),
            @ApiResponse(responseCode = "404", description = "Unknown id",
                    content = @Content(schema = @Schema(implementation = ApiError.class)))
    })
    public RequestResponse get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('RESIDENT','ADMIN')")
    @Operation(summary = "Raise a new maintenance request")
    public ResponseEntity<RequestResponse> create(@Valid @RequestBody CreateRequest req) {
        RequestResponse created = service.create(req);
        return ResponseEntity.created(URI.create("/api/v1/requests/" + created.id())).body(created);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Replace the editable fields of a request")
    public RequestResponse update(@PathVariable Long id, @Valid @RequestBody UpdateRequest req) {
        return service.update(id, req);
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Advance the request workflow",
            description = "OPEN -> ASSIGNED -> IN_PROGRESS -> RESOLVED -> CLOSED. Illegal jumps return 422.")
    public RequestResponse changeStatus(@PathVariable Long id, @Valid @RequestBody StatusUpdate req) {
        return service.changeStatus(id, req);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete a request (ADMIN only)")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/comments")
    @Operation(summary = "List the conversation on a request")
    public List<CommentResponse> comments(@PathVariable Long id) {
        return service.comments(id);
    }

    @PostMapping("/{id}/comments")
    @Operation(summary = "Add a comment to a request")
    public ResponseEntity<CommentResponse> addComment(@PathVariable Long id,
                                                      @Valid @RequestBody CommentRequest req) {
        CommentResponse c = service.addComment(id, req);
        return ResponseEntity.created(URI.create("/api/v1/requests/" + id + "/comments/" + c.id())).body(c);
    }
}
