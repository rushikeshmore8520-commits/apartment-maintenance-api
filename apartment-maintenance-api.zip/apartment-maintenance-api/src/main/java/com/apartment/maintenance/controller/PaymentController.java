package com.apartment.maintenance.controller;

import com.apartment.maintenance.dto.PageResponse;
import com.apartment.maintenance.dto.PaymentDtos.*;
import com.apartment.maintenance.entity.PaymentStatus;
import com.apartment.maintenance.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;

@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
@Tag(name = "Maintenance Bills", description = "Monthly maintenance dues per flat")
@SecurityRequirement(name = "bearerAuth")
public class PaymentController {

    private final PaymentService paymentService;

    @GetMapping
    @Operation(summary = "List bills (residents see only their own flat)")
    public PageResponse<PaymentResponse> list(
            @RequestParam(required = false) Long flatId,
            @RequestParam(required = false) PaymentStatus status,
            @PageableDefault(size = 10, sort = "dueDate", direction = Sort.Direction.DESC) Pageable pageable) {
        return paymentService.list(flatId, status, pageable);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Raise a monthly bill for a flat (ADMIN only)")
    public ResponseEntity<PaymentResponse> create(@Valid @RequestBody CreatePayment req) {
        PaymentResponse created = paymentService.create(req);
        return ResponseEntity.created(URI.create("/api/v1/payments/" + created.id())).body(created);
    }

    @PatchMapping("/{id}/settle")
    @Operation(summary = "Mark a bill as paid")
    public PaymentResponse settle(@PathVariable Long id, @Valid @RequestBody SettlePayment req) {
        return paymentService.settle(id, req);
    }
}
