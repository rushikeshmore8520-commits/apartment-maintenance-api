package com.apartment.maintenance.service;

import com.apartment.maintenance.dto.FlatDtos.*;
import com.apartment.maintenance.dto.PageResponse;
import com.apartment.maintenance.entity.Flat;
import com.apartment.maintenance.exception.*;
import com.apartment.maintenance.repository.FlatRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class FlatService {

    private final FlatRepository flatRepository;

    public PageResponse<FlatResponse> list(Pageable pageable) {
        return PageResponse.of(flatRepository.findAll(pageable), FlatResponse::from);
    }

    public FlatResponse get(Long id) {
        return FlatResponse.from(find(id));
    }

    @Transactional
    public FlatResponse create(FlatRequest req) {
        if (flatRepository.existsByFlatNumber(req.flatNumber())) {
            throw new DuplicateResourceException("Flat " + req.flatNumber() + " already exists");
        }
        Flat flat = Flat.builder()
                .flatNumber(req.flatNumber()).block(req.block()).floor(req.floor())
                .ownerName(req.ownerName()).areaSqft(req.areaSqft()).occupied(req.occupied())
                .build();
        return FlatResponse.from(flatRepository.save(flat));
    }

    @Transactional
    public FlatResponse update(Long id, FlatRequest req) {
        Flat flat = find(id);
        if (!flat.getFlatNumber().equals(req.flatNumber())
                && flatRepository.existsByFlatNumber(req.flatNumber())) {
            throw new DuplicateResourceException("Flat " + req.flatNumber() + " already exists");
        }
        flat.setFlatNumber(req.flatNumber());
        flat.setBlock(req.block());
        flat.setFloor(req.floor());
        flat.setOwnerName(req.ownerName());
        flat.setAreaSqft(req.areaSqft());
        flat.setOccupied(req.occupied());
        return FlatResponse.from(flatRepository.save(flat));
    }

    @Transactional
    public void delete(Long id) {
        flatRepository.delete(find(id));
    }

    private Flat find(Long id) {
        return flatRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flat", id));
    }
}
