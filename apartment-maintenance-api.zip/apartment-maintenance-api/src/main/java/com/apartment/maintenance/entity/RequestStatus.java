package com.apartment.maintenance.entity;

import java.util.EnumSet;
import java.util.Set;

public enum RequestStatus {
    OPEN,
    ASSIGNED,
    IN_PROGRESS,
    RESOLVED,
    CLOSED,
    REJECTED;

    /** Allowed forward transitions - enforced in MaintenanceRequestService. */
    public Set<RequestStatus> allowedNext() {
        return switch (this) {
            case OPEN -> EnumSet.of(ASSIGNED, REJECTED);
            case ASSIGNED -> EnumSet.of(IN_PROGRESS, REJECTED);
            case IN_PROGRESS -> EnumSet.of(RESOLVED);
            case RESOLVED -> EnumSet.of(CLOSED, IN_PROGRESS);
            case CLOSED, REJECTED -> EnumSet.noneOf(RequestStatus.class);
        };
    }
}
