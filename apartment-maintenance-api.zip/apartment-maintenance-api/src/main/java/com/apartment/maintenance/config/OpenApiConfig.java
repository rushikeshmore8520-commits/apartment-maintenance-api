package com.apartment.maintenance.config;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.*;
import io.swagger.v3.oas.models.security.*;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    private static final String SCHEME = "bearerAuth";

    @Bean
    public OpenAPI apartmentMaintenanceOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Apartment Maintenance REST API")
                        .version("1.0.0")
                        .description("""
                                REST API for managing an apartment society: flats, residents,
                                maintenance complaints and monthly maintenance bills.

                                **Authentication** - call `POST /api/v1/auth/login`, copy the
                                `accessToken` and click *Authorize* above. Every endpoint other
                                than `/api/v1/auth/**` returns **401** without a valid token.

                                **Seeded accounts** - admin@apt.com / Admin@123,
                                tech@apt.com / Tech@123, resident@apt.com / Resident@123
                                """)
                        .contact(new Contact().name("API Support").email("support@apt.com"))
                        .license(new License().name("MIT")))
                .servers(List.of(new Server().url("http://localhost:8080").description("Local")))
                .addSecurityItem(new SecurityRequirement().addList(SCHEME))
                .components(new Components().addSecuritySchemes(SCHEME,
                        new SecurityScheme()
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("JWT")
                                .description("Paste the accessToken returned by /api/v1/auth/login")));
    }
}
