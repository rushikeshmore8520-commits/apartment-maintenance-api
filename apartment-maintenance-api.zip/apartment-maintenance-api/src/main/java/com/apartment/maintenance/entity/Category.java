package com.apartment.maintenance.entity;

public enum Category {
    PLUMBING,
    ELECTRICAL,
    CARPENTRY,
    ELEVATOR,
    HOUSEKEEPING,
    SECURITY,
    COMMON_AREA,
    OTHER
}
