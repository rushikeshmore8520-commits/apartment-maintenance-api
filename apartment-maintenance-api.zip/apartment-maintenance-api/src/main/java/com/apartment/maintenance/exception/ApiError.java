package com.apartment.maintenance.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "ApiError", description = "Uniform error body returned by every failing endpoint")
public record ApiError(
        @Schema(example = "2026-09-19T10:15:30Z") String timestamp,
        @Schema(example = "400") int status,
        @Schema(example = "VALIDATION_FAILED") String code,
        @Schema(example = "Request validation failed") String message,
        @Schema(example = "/api/v1/requests") String path,
        List<Map<String, String>> details
) {
    public static ApiError of(int status, String code, String message, String path) {
        return new ApiError(Instant.now().toString(), status, code, message, path, null);
    }

    public static ApiError of(int status, String code, String message, String path,
                              List<Map<String, String>> details) {
        return new ApiError(Instant.now().toString(), status, code, message, path, details);
    }
}
