package com.apartment.maintenance.repository;

import com.apartment.maintenance.entity.Payment;
import com.apartment.maintenance.entity.PaymentStatus;
import org.springframework.data.jpa.domain.Specification;

public final class PaymentSpecifications {

    private PaymentSpecifications() {}

    public static Specification<Payment> hasFlat(Long flatId) {
        return (root, q, cb) -> flatId == null ? cb.conjunction() : cb.equal(root.get("flat").get("id"), flatId);
    }

    public static Specification<Payment> hasStatus(PaymentStatus status) {
        return (root, q, cb) -> status == null ? cb.conjunction() : cb.equal(root.get("status"), status);
    }
}
