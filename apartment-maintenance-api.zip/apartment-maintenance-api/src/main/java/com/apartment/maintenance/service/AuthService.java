package com.apartment.maintenance.service;

import com.apartment.maintenance.dto.AuthDtos.*;
import com.apartment.maintenance.dto.UserDtos.UserResponse;
import com.apartment.maintenance.entity.*;
import com.apartment.maintenance.exception.*;
import com.apartment.maintenance.repository.*;
import com.apartment.maintenance.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final FlatRepository flatRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    @Transactional
    public UserResponse register(RegisterRequest req) {
        if (userRepository.existsByEmail(req.email())) {
            throw new DuplicateResourceException("Email " + req.email() + " is already registered");
        }

        Flat flat = null;
        if (req.flatId() != null) {
            flat = flatRepository.findById(req.flatId())
                    .orElseThrow(() -> new ResourceNotFoundException("Flat", req.flatId()));
        }

        // Self-registration can only create residents; staff accounts are created by an admin
        // through POST /api/v1/users.
        Role role = req.role() == null ? Role.RESIDENT : req.role();
        if (role != Role.RESIDENT) {
            throw new InvalidStateTransitionException(
                    "Only RESIDENT accounts can be self-registered. Ask an admin to create staff accounts.");
        }

        User user = User.builder()
                .email(req.email().toLowerCase())
                .password(passwordEncoder.encode(req.password()))
                .fullName(req.fullName())
                .phone(req.phone())
                .role(role)
                .flat(flat)
                .build();

        return UserResponse.from(userRepository.save(user));
    }

    public AuthResponse login(LoginRequest req) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.email().toLowerCase(), req.password()));

        User user = userRepository.findByEmail(req.email().toLowerCase())
                .orElseThrow(() -> new BadCredentialsException("Bad credentials"));

        return new AuthResponse(
                jwtService.generateToken(user),
                "Bearer",
                jwtService.getExpirySeconds(),
                UserResponse.from(user));
    }
}
