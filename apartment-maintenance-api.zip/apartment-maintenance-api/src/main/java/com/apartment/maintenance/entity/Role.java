package com.apartment.maintenance.entity;

public enum Role {
    RESIDENT,
    TECHNICIAN,
    ADMIN
}
