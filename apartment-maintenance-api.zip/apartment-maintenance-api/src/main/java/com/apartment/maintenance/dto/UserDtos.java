package com.apartment.maintenance.dto;

import com.apartment.maintenance.entity.Role;
import com.apartment.maintenance.entity.User;
import io.swagger.v3.oas.annotations.media.Schema;

public class UserDtos {

    @Schema(name = "UserResponse")
    public record UserResponse(
            Long id,
            String email,
            String fullName,
            String phone,
            Role role,
            Long flatId,
            String flatNumber
    ) {
        public static UserResponse from(User u) {
            return new UserResponse(
                    u.getId(), u.getEmail(), u.getFullName(), u.getPhone(), u.getRole(),
                    u.getFlat() == null ? null : u.getFlat().getId(),
                    u.getFlat() == null ? null : u.getFlat().getFlatNumber());
        }
    }
}
