package com.apartment.maintenance.dto;

import com.apartment.maintenance.entity.Role;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;

public class AuthDtos {

    @Schema(name = "RegisterRequest", description = "Payload to self-register a resident or to let an admin create staff accounts")
    public record RegisterRequest(
            @NotBlank @Email @Schema(example = "resident@apt.com") String email,
            @NotBlank @Size(min = 8, max = 72) @Schema(example = "Resident@123") String password,
            @NotBlank @Schema(example = "Ravi Sharma") String fullName,
            @Pattern(regexp = "^[0-9]{10}$", message = "phone must be 10 digits")
            @Schema(example = "9876543210") String phone,
            @Schema(example = "RESIDENT", description = "Defaults to RESIDENT when omitted") Role role,
            @Schema(example = "1", description = "Flat to link the resident to") Long flatId
    ) {}

    @Schema(name = "LoginRequest")
    public record LoginRequest(
            @NotBlank @Email @Schema(example = "admin@apt.com") String email,
            @NotBlank @Schema(example = "Admin@123") String password
    ) {}

    @Schema(name = "AuthResponse")
    public record AuthResponse(
            String accessToken,
            String tokenType,
            long expiresInSeconds,
            UserDtos.UserResponse user
    ) {}
}
