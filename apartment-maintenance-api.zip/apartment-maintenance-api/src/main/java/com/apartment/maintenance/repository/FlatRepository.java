package com.apartment.maintenance.repository;

import com.apartment.maintenance.entity.Flat;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FlatRepository extends JpaRepository<Flat, Long> {
    boolean existsByFlatNumber(String flatNumber);
}
