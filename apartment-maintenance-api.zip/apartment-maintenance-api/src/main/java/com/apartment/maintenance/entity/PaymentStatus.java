package com.apartment.maintenance.entity;

public enum PaymentStatus {
    PENDING,
    PAID,
    OVERDUE
}
