package com.apartment.maintenance.dto;

import com.apartment.maintenance.entity.*;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.Instant;

public class RequestDtos {

    @Schema(name = "CreateMaintenanceRequest")
    public record CreateRequest(
            @NotBlank @Size(max = 150) @Schema(example = "Kitchen tap leaking continuously") String title,
            @NotBlank @Size(max = 2000) @Schema(example = "Water leaks from the base of the kitchen tap since yesterday evening.") String description,
            @NotNull @Schema(example = "PLUMBING") Category category,
            @NotNull @Schema(example = "HIGH") Priority priority,
            @Schema(example = "1", description = "Required for ADMIN; residents default to their own flat") Long flatId
    ) {}

    @Schema(name = "UpdateMaintenanceRequest", description = "Full replacement of the editable fields (PUT)")
    public record UpdateRequest(
            @NotBlank @Size(max = 150) String title,
            @NotBlank @Size(max = 2000) String description,
            @NotNull Category category,
            @NotNull Priority priority
    ) {}

    @Schema(name = "StatusUpdateRequest", description = "Partial update of workflow state (PATCH)")
    public record StatusUpdate(
            @NotNull @Schema(example = "ASSIGNED") RequestStatus status,
            @Schema(example = "3", description = "Technician id, required when moving to ASSIGNED") Long assignedToId,
            @DecimalMin("0.0") @Schema(example = "750.00") BigDecimal cost,
            @Size(max = 1000) @Schema(example = "Assigned to in-house plumber.") String note
    ) {}

    @Schema(name = "MaintenanceRequestResponse")
    public record RequestResponse(
            Long id, String title, String description,
            Category category, Priority priority, RequestStatus status,
            Long flatId, String flatNumber,
            Long raisedById, String raisedByName,
            Long assignedToId, String assignedToName,
            BigDecimal cost,
            Instant createdAt, Instant updatedAt, Instant resolvedAt
    ) {
        public static RequestResponse from(MaintenanceRequest r) {
            User a = r.getAssignedTo();
            return new RequestResponse(
                    r.getId(), r.getTitle(), r.getDescription(), r.getCategory(), r.getPriority(), r.getStatus(),
                    r.getFlat().getId(), r.getFlat().getFlatNumber(),
                    r.getRaisedBy().getId(), r.getRaisedBy().getFullName(),
                    a == null ? null : a.getId(), a == null ? null : a.getFullName(),
                    r.getCost(), r.getCreatedAt(), r.getUpdatedAt(), r.getResolvedAt());
        }
    }

    @Schema(name = "CommentRequest")
    public record CommentRequest(
            @NotBlank @Size(max = 1000) @Schema(example = "Plumber will visit tomorrow between 10-12.") String message
    ) {}

    @Schema(name = "CommentResponse")
    public record CommentResponse(Long id, Long requestId, Long authorId, String authorName,
                                  String message, Instant createdAt) {
        public static CommentResponse from(Comment c) {
            return new CommentResponse(c.getId(), c.getRequest().getId(), c.getAuthor().getId(),
                    c.getAuthor().getFullName(), c.getMessage(), c.getCreatedAt());
        }
    }
}
