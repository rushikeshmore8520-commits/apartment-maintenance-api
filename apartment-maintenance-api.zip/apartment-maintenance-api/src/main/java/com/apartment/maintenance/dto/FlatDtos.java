package com.apartment.maintenance.dto;

import com.apartment.maintenance.entity.Flat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;

public class FlatDtos {

    @Schema(name = "FlatRequest")
    public record FlatRequest(
            @NotBlank @Schema(example = "A-402") String flatNumber,
            @NotBlank @Schema(example = "A") String block,
            @NotNull @Min(0) @Max(60) @Schema(example = "4") Integer floor,
            @NotBlank @Schema(example = "Ravi Sharma") String ownerName,
            @NotNull @Min(100) @Schema(example = "1150") Integer areaSqft,
            @NotNull @Schema(example = "true") Boolean occupied
    ) {}

    @Schema(name = "FlatResponse")
    public record FlatResponse(
            Long id, String flatNumber, String block, Integer floor,
            String ownerName, Integer areaSqft, Boolean occupied
    ) {
        public static FlatResponse from(Flat f) {
            return new FlatResponse(f.getId(), f.getFlatNumber(), f.getBlock(), f.getFloor(),
                    f.getOwnerName(), f.getAreaSqft(), f.getOccupied());
        }
    }
}
