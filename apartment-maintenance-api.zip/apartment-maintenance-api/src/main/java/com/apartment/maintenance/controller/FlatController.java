package com.apartment.maintenance.controller;

import com.apartment.maintenance.dto.FlatDtos.*;
import com.apartment.maintenance.dto.PageResponse;
import com.apartment.maintenance.service.FlatService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;

@RestController
@RequestMapping("/api/v1/flats")
@RequiredArgsConstructor
@Tag(name = "Flats", description = "Master data for the flats in the society")
@SecurityRequirement(name = "bearerAuth")
public class FlatController {

    private final FlatService flatService;

    @GetMapping
    @Operation(summary = "List flats (paged)")
    public PageResponse<FlatResponse> list(
            @PageableDefault(size = 10, sort = "flatNumber", direction = Sort.Direction.ASC) Pageable pageable) {
        return flatService.list(pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a single flat")
    public FlatResponse get(@PathVariable Long id) {
        return flatService.get(id);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Create a flat (ADMIN only)")
    public ResponseEntity<FlatResponse> create(@Valid @RequestBody FlatRequest req) {
        FlatResponse created = flatService.create(req);
        return ResponseEntity.created(URI.create("/api/v1/flats/" + created.id())).body(created);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Replace a flat (ADMIN only)")
    public FlatResponse update(@PathVariable Long id, @Valid @RequestBody FlatRequest req) {
        return flatService.update(id, req);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete a flat (ADMIN only)")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        flatService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
