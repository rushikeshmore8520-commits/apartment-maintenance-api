package com.apartment.maintenance.dto;

import com.apartment.maintenance.entity.Payment;
import com.apartment.maintenance.entity.PaymentStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

public class PaymentDtos {

    @Schema(name = "CreatePaymentRequest", description = "Raise a monthly maintenance bill for a flat")
    public record CreatePayment(
            @NotNull @Schema(example = "1") Long flatId,
            @NotBlank @Pattern(regexp = "^\\d{4}-(0[1-9]|1[0-2])$", message = "billingMonth must be YYYY-MM")
            @Schema(example = "2026-09") String billingMonth,
            @NotNull @DecimalMin("1.0") @Schema(example = "3500.00") BigDecimal amount,
            @NotNull @Schema(example = "2026-09-10") LocalDate dueDate
    ) {}

    @Schema(name = "SettlePaymentRequest")
    public record SettlePayment(
            @NotBlank @Size(max = 40) @Schema(example = "UPI-8827361") String referenceNo
    ) {}

    @Schema(name = "PaymentResponse")
    public record PaymentResponse(Long id, Long flatId, String flatNumber, String billingMonth,
                                  BigDecimal amount, PaymentStatus status, LocalDate dueDate,
                                  Instant paidAt, String referenceNo) {
        public static PaymentResponse from(Payment p) {
            return new PaymentResponse(p.getId(), p.getFlat().getId(), p.getFlat().getFlatNumber(),
                    p.getBillingMonth(), p.getAmount(), p.getStatus(), p.getDueDate(),
                    p.getPaidAt(), p.getReferenceNo());
        }
    }
}
