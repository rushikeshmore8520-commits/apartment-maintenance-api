package com.apartment.maintenance.entity;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}
