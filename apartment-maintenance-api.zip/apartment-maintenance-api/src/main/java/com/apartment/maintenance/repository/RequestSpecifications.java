package com.apartment.maintenance.repository;

import com.apartment.maintenance.entity.*;
import org.springframework.data.jpa.domain.Specification;

/**
 * Criteria-API filters. Using Specifications instead of a JPQL query with
 * ":param IS NULL" keeps the null-safe filtering type-safe and composable.
 */
public final class RequestSpecifications {

    private RequestSpecifications() {}

    public static Specification<MaintenanceRequest> hasStatus(RequestStatus status) {
        return (root, q, cb) -> status == null ? cb.conjunction() : cb.equal(root.get("status"), status);
    }

    public static Specification<MaintenanceRequest> hasCategory(Category category) {
        return (root, q, cb) -> category == null ? cb.conjunction() : cb.equal(root.get("category"), category);
    }

    public static Specification<MaintenanceRequest> hasPriority(Priority priority) {
        return (root, q, cb) -> priority == null ? cb.conjunction() : cb.equal(root.get("priority"), priority);
    }

    public static Specification<MaintenanceRequest> hasFlat(Long flatId) {
        return (root, q, cb) -> flatId == null ? cb.conjunction() : cb.equal(root.get("flat").get("id"), flatId);
    }

    public static Specification<MaintenanceRequest> assignedTo(Long userId) {
        return (root, q, cb) -> userId == null ? cb.conjunction() : cb.equal(root.get("assignedTo").get("id"), userId);
    }
}
