package com.apartment.maintenance.config;

import com.apartment.maintenance.entity.*;
import com.apartment.maintenance.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Loads demo data so the API can be demonstrated immediately after startup. */
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final FlatRepository flatRepository;
    private final UserRepository userRepository;
    private final MaintenanceRequestRepository requestRepository;
    private final PaymentRepository paymentRepository;
    private final PasswordEncoder encoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) return;

        Flat a402 = flatRepository.save(Flat.builder().flatNumber("A-402").block("A").floor(4)
                .ownerName("Ravi Sharma").areaSqft(1150).occupied(true).build());
        Flat b201 = flatRepository.save(Flat.builder().flatNumber("B-201").block("B").floor(2)
                .ownerName("Meera Iyer").areaSqft(980).occupied(true).build());
        flatRepository.save(Flat.builder().flatNumber("C-101").block("C").floor(1)
                .ownerName("Society Office").areaSqft(600).occupied(false).build());

        User admin = userRepository.save(User.builder().email("admin@apt.com")
                .password(encoder.encode("Admin@123")).fullName("Society Admin")
                .phone("9000000001").role(Role.ADMIN).build());

        User tech = userRepository.save(User.builder().email("tech@apt.com")
                .password(encoder.encode("Tech@123")).fullName("Suresh Plumber")
                .phone("9000000002").role(Role.TECHNICIAN).build());

        User resident = userRepository.save(User.builder().email("resident@apt.com")
                .password(encoder.encode("Resident@123")).fullName("Ravi Sharma")
                .phone("9876543210").role(Role.RESIDENT).flat(a402).build());

        userRepository.save(User.builder().email("meera@apt.com")
                .password(encoder.encode("Meera@123")).fullName("Meera Iyer")
                .phone("9876543211").role(Role.RESIDENT).flat(b201).build());

        requestRepository.save(MaintenanceRequest.builder()
                .title("Kitchen tap leaking continuously")
                .description("Water leaks from the base of the kitchen tap since yesterday evening.")
                .category(Category.PLUMBING).priority(Priority.HIGH).status(RequestStatus.OPEN)
                .flat(a402).raisedBy(resident).build());

        requestRepository.save(MaintenanceRequest.builder()
                .title("Lift making grinding noise")
                .description("Block B lift makes a loud grinding sound between floors 3 and 4.")
                .category(Category.ELEVATOR).priority(Priority.URGENT).status(RequestStatus.ASSIGNED)
                .flat(b201).raisedBy(resident).assignedTo(tech).build());

        paymentRepository.save(Payment.builder().flat(a402).billingMonth("2026-09")
                .amount(new BigDecimal("3500.00")).status(PaymentStatus.PENDING)
                .dueDate(LocalDate.of(2026, 9, 10)).build());

        paymentRepository.save(Payment.builder().flat(b201).billingMonth("2026-09")
                .amount(new BigDecimal("2900.00")).status(PaymentStatus.PENDING)
                .dueDate(LocalDate.of(2026, 9, 10)).build());

        System.out.println("[DataSeeder] Demo data loaded. Admin user: " + admin.getEmail());
    }
}
