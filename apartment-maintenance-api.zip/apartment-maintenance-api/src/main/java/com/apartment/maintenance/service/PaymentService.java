package com.apartment.maintenance.service;

import com.apartment.maintenance.dto.PageResponse;
import com.apartment.maintenance.dto.PaymentDtos.*;
import com.apartment.maintenance.entity.*;
import com.apartment.maintenance.exception.*;
import com.apartment.maintenance.repository.*;
import com.apartment.maintenance.security.CurrentUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final FlatRepository flatRepository;
    private final CurrentUser currentUser;

    public PageResponse<PaymentResponse> list(Long flatId, PaymentStatus status, Pageable pageable) {
        User me = currentUser.get();
        Long effectiveFlatId = flatId;
        if (me.getRole() == Role.RESIDENT) {
            if (me.getFlat() == null) throw new AccessDeniedException("Your account is not linked to a flat");
            effectiveFlatId = me.getFlat().getId();
        }
        Specification<Payment> spec = Specification
                .where(PaymentSpecifications.hasFlat(effectiveFlatId))
                .and(PaymentSpecifications.hasStatus(status));
        return PageResponse.of(paymentRepository.findAll(spec, pageable), PaymentResponse::from);
    }

    @Transactional
    public PaymentResponse create(CreatePayment req) {
        if (paymentRepository.existsByFlatIdAndBillingMonth(req.flatId(), req.billingMonth())) {
            throw new DuplicateResourceException(
                    "A bill for " + req.billingMonth() + " already exists for flat " + req.flatId());
        }
        Flat flat = flatRepository.findById(req.flatId())
                .orElseThrow(() -> new ResourceNotFoundException("Flat", req.flatId()));

        Payment p = Payment.builder()
                .flat(flat).billingMonth(req.billingMonth()).amount(req.amount())
                .dueDate(req.dueDate()).status(PaymentStatus.PENDING)
                .build();
        return PaymentResponse.from(paymentRepository.save(p));
    }

    @Transactional
    public PaymentResponse settle(Long id, SettlePayment req) {
        Payment p = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", id));

        User me = currentUser.get();
        if (me.getRole() == Role.RESIDENT
                && (me.getFlat() == null || !me.getFlat().getId().equals(p.getFlat().getId()))) {
            throw new AccessDeniedException("This bill does not belong to your flat");
        }
        if (p.getStatus() == PaymentStatus.PAID) {
            throw new DuplicateResourceException("Bill " + id + " has already been settled");
        }

        p.setStatus(PaymentStatus.PAID);
        p.setPaidAt(Instant.now());
        p.setReferenceNo(req.referenceNo());
        return PaymentResponse.from(paymentRepository.save(p));
    }
}
