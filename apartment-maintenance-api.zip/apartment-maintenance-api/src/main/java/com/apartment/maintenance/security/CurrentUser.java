package com.apartment.maintenance.security;

import com.apartment.maintenance.entity.Role;
import com.apartment.maintenance.entity.User;
import com.apartment.maintenance.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/** Convenience holder that resolves the authenticated principal into a User entity. */
@Component
@RequiredArgsConstructor
public class CurrentUser {

    private final UserRepository userRepository;

    public User get() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new IllegalStateException("Authenticated user not found in database"));
    }

    public boolean isAdmin() {
        return get().getRole() == Role.ADMIN;
    }
}
