package com.apartment.maintenance.service;

import com.apartment.maintenance.dto.AuthDtos.RegisterRequest;
import com.apartment.maintenance.dto.PageResponse;
import com.apartment.maintenance.dto.UserDtos.UserResponse;
import com.apartment.maintenance.entity.*;
import com.apartment.maintenance.exception.*;
import com.apartment.maintenance.repository.*;
import com.apartment.maintenance.security.CurrentUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final FlatRepository flatRepository;
    private final PasswordEncoder passwordEncoder;
    private final CurrentUser currentUser;

    public PageResponse<UserResponse> list(Role role, Pageable pageable) {
        var page = (role == null)
                ? userRepository.findAll(pageable)
                : userRepository.findByRole(role, pageable);
        return PageResponse.of(page, UserResponse::from);
    }

    public UserResponse me() {
        return UserResponse.from(currentUser.get());
    }

    /** Admin-only creation, used for TECHNICIAN and ADMIN accounts. */
    @Transactional
    public UserResponse create(RegisterRequest req) {
        if (userRepository.existsByEmail(req.email())) {
            throw new DuplicateResourceException("Email " + req.email() + " is already registered");
        }
        Flat flat = null;
        if (req.flatId() != null) {
            flat = flatRepository.findById(req.flatId())
                    .orElseThrow(() -> new ResourceNotFoundException("Flat", req.flatId()));
        }
        User u = User.builder()
                .email(req.email().toLowerCase())
                .password(passwordEncoder.encode(req.password()))
                .fullName(req.fullName())
                .phone(req.phone())
                .role(req.role() == null ? Role.RESIDENT : req.role())
                .flat(flat)
                .build();
        return UserResponse.from(userRepository.save(u));
    }

    @Transactional
    public void delete(Long id) {
        User u = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
        userRepository.delete(u);
    }
}
