package com.apartment.maintenance.repository;

import com.apartment.maintenance.entity.MaintenanceRequest;
import com.apartment.maintenance.entity.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface MaintenanceRequestRepository
        extends JpaRepository<MaintenanceRequest, Long>, JpaSpecificationExecutor<MaintenanceRequest> {

    long countByStatus(RequestStatus status);
}
