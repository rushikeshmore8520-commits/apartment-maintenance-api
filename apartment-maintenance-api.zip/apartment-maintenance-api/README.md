# Apartment Maintenance REST API

A secured, versioned REST API for running an apartment society: flats, residents,
maintenance complaints with a proper workflow, and monthly maintenance bills.

Built with Spring Boot 3, Spring Security + JWT, Spring Data JPA, H2 and
springdoc-openapi (Swagger UI).

---

## 1. Tech stack

| Layer | Choice | Why |
|---|---|---|
| Language / runtime | Java 17 | LTS, records + sealed switch used in the code |
| Service framework | Spring Boot 3.3.4 (Spring Web MVC) | Option B of the problem statement |
| Security | Spring Security 6 + JJWT 0.12 (HS256) | Stateless bearer-token auth with role-based rules |
| Persistence | Spring Data JPA (Hibernate 6) | Repositories + Criteria Specifications for filtering |
| Database | H2 in-memory | Zero setup for evaluation; swap to MySQL with 3 property lines |
| Validation | Jakarta Bean Validation (Hibernate Validator) | Declarative `@NotBlank`, `@Pattern`, etc. |
| Documentation | springdoc-openapi 2.6 | Serves `/v3/api-docs` + Swagger UI from annotations |
| Testing | JUnit 5 + REST Assured | End-to-end tests including the 401/403 security proofs |
| Build | Maven | `mvn spring-boot:run` |

---

## 2. Architecture

```mermaid
flowchart TB
    subgraph Clients
        P[Postman / REST Assured]
        S[Swagger UI]
        W[Any web or mobile client]
    end

    subgraph SpringBoot["Spring Boot application :8080"]
        direction TB
        F["JwtAuthenticationFilter<br/>(validates Bearer token)"]
        SEC["Spring Security FilterChain<br/>stateless + @PreAuthorize"]
        C["Controllers<br/>Auth / Users / Flats / Requests / Payments"]
        SV["Services<br/>business rules + state machine"]
        R["Spring Data JPA repositories<br/>+ Criteria Specifications"]
        E["GlobalExceptionHandler<br/>uniform ApiError body"]
    end

    DB[(H2 in-memory database)]

    P --> F
    S --> F
    W --> F
    F --> SEC --> C --> SV --> R --> DB
    C -.errors.-> E
    SV -.errors.-> E
```

Request flow in words: every call enters the security filter chain, where
`JwtAuthenticationFilter` looks for `Authorization: Bearer <token>`, verifies the
HS256 signature and expiry, and populates the `SecurityContext`. Controllers stay
thin — they validate the DTO and delegate. Services hold the business rules
(who may see what, the complaint state machine, duplicate-bill checks).
Repositories talk to H2. Any exception is converted by `GlobalExceptionHandler`
into one uniform JSON error shape.

### Package layout

```
com.apartment.maintenance
├── config          SecurityConfig, OpenApiConfig, DataSeeder
├── security        JwtService, JwtAuthenticationFilter, CustomUserDetailsService, CurrentUser
├── entity          User, Flat, MaintenanceRequest, Comment, Payment + enums
├── dto             request/response records (no entity is ever exposed directly)
├── repository      Spring Data repositories + Criteria Specifications
├── service         AuthService, FlatService, MaintenanceRequestService, PaymentService, UserService
├── controller      REST controllers under /api/v1
└── exception       ApiError + GlobalExceptionHandler + domain exceptions
```

---

## 3. Setup

### Prerequisites
- JDK 17 or newer (`java -version`)
- Maven 3.8+ (`mvn -v`) — or use the bundled wrapper if you add one

### Run

```bash
# from the project root
mvn clean spring-boot:run
```

The API starts on **http://localhost:8080**.

| Thing | URL |
|---|---|
| Swagger UI | http://localhost:8080/swagger-ui.html |
| OpenAPI JSON (generated) | http://localhost:8080/v3/api-docs |
| OpenAPI YAML (generated) | http://localhost:8080/v3/api-docs.yaml |
| H2 console | http://localhost:8080/h2-console (JDBC URL `jdbc:h2:mem:apartmentdb`, user `sa`, empty password) |

### Seeded demo accounts

| Email | Password | Role |
|---|---|---|
| admin@apt.com | `Admin@123` | ADMIN |
| tech@apt.com | `Tech@123` | TECHNICIAN |
| resident@apt.com | `Resident@123` | RESIDENT (flat A-402) |
| meera@apt.com | `Meera@123` | RESIDENT (flat B-201) |

### Run the tests

```bash
mvn test
```

The REST Assured suite in `src/test/java/.../MaintenanceApiRestAssuredTest.java`
covers the 401 (no token / tampered token / wrong password), 403 (wrong role),
200 (valid token), 400, 404, 409 and 422 cases.

### Switch to MySQL

Replace the datasource block in `application.yml` and add the MySQL driver:

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/apartmentdb
    username: root
    password: yourpassword
  jpa:
    hibernate:
      ddl-auto: update
```

---

## 4. Trying it in 60 seconds (curl)

```bash
# 1. No token -> 401
curl -i http://localhost:8080/api/v1/requests

# 2. Log in
TOKEN=$(curl -s -X POST http://localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@apt.com","password":"Admin@123"}' | jq -r .accessToken)

# 3. Valid token -> 200
curl -i http://localhost:8080/api/v1/requests -H "Authorization: Bearer $TOKEN"

# 4. Raise a complaint as a resident
RTOKEN=$(curl -s -X POST http://localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"resident@apt.com","password":"Resident@123"}' | jq -r .accessToken)

curl -s -X POST http://localhost:8080/api/v1/requests \
  -H "Authorization: Bearer $RTOKEN" -H 'Content-Type: application/json' \
  -d '{"title":"Kitchen tap leaking","description":"Leaks from the base since yesterday.","category":"PLUMBING","priority":"HIGH"}'
```

---

## 5. Endpoint summary

| Method | Path | Roles | Purpose |
|---|---|---|---|
| POST | `/api/v1/auth/register` | public | Self-register a resident |
| POST | `/api/v1/auth/login` | public | Obtain a JWT |
| GET | `/api/v1/users/me` | any | Profile of the token holder |
| GET/POST | `/api/v1/users` | ADMIN | List / create accounts |
| DELETE | `/api/v1/users/{id}` | ADMIN | Remove an account |
| GET | `/api/v1/flats` | any | Paged list of flats |
| GET | `/api/v1/flats/{id}` | any | One flat |
| POST/PUT/DELETE | `/api/v1/flats...` | ADMIN | Manage flats |
| GET | `/api/v1/requests` | any (scoped) | Filter + sort + page complaints |
| POST | `/api/v1/requests` | RESIDENT, ADMIN | Raise a complaint |
| GET/PUT/DELETE | `/api/v1/requests/{id}` | scoped | Read / replace / delete |
| PATCH | `/api/v1/requests/{id}/status` | scoped | Advance the workflow |
| GET/POST | `/api/v1/requests/{id}/comments` | scoped | Conversation thread |
| GET | `/api/v1/requests/summary` | ADMIN | Counts per status |
| GET | `/api/v1/payments` | any (scoped) | Maintenance bills |
| POST | `/api/v1/payments` | ADMIN | Raise a monthly bill |
| PATCH | `/api/v1/payments/{id}/settle` | scoped | Mark as paid |

"Scoped" means: a resident only ever touches their own flat's data, a technician
only the requests assigned to them, and an admin sees everything.

Full request/response examples are in [`docs/API_DESIGN.md`](docs/API_DESIGN.md).

---

## 6. Complaint state machine

```
OPEN ──▶ ASSIGNED ──▶ IN_PROGRESS ──▶ RESOLVED ──▶ CLOSED
  │           │                            │
  ▼           ▼                            └──▶ IN_PROGRESS (reopened)
REJECTED   REJECTED
```

Any other jump returns **422 Unprocessable Entity** with code
`INVALID_STATE_TRANSITION`.

---

## 7. Deliverables in this repository

| Deliverable | Location |
|---|---|
| Source code | `src/` |
| API design document | `docs/API_DESIGN.md` |
| OpenAPI 3.x spec | `openapi.yaml` (hand-authored) + live at `/v3/api-docs` |
| Postman collection | `postman/Apartment-Maintenance-API.postman_collection.json` |
| REST Assured tests | `src/test/java/com/apartment/maintenance/MaintenanceApiRestAssuredTest.java` |
| Security proof | `docs/SECURITY_PROOF.md` + screenshots in `docs/screenshots/` |
| Report | `docs/REPORT.md` |

### Screenshots still to capture

Put these PNGs into `docs/screenshots/` before you submit:

1. `swagger-ui.png` — the Swagger UI page with all tags expanded.
2. `401-no-token.png` — Postman `GET /api/v1/requests` with no Authorization header, showing **401**.
3. `200-with-token.png` — the same call with `Authorization: Bearer <token>`, showing **200**.
4. `403-wrong-role.png` — resident token on `POST /api/v1/flats`, showing **403**.
5. `postman-runner.png` — the Collection Runner summary with all tests passing.
6. `h2-console.png` — optional, the seeded tables.
